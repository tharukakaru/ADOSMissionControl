// Shared domain types for the ARC OS · C2 battle-management screen. Demo data only.

export type EntityClass = "HYENA" | "SENTINEL" | "HOST" | "FRND" | "NEUT";
export type MarkerKind = "host" | "frnd" | "sent" | "hy";

export interface Entity {
  id: string;
  name: string;
  badge: string;      // small class tag shown after the name (HYENA, SENTINEL, …)
  sub: string;        // descriptor line
  confidence: number; // 0-100
  tone: "hy" | "sent" | "host" | "frnd" | "neut"; // name color
  status: string;     // status dot color (css var)
}

export interface Coa {
  id: string;
  rec?: boolean;
  time: string;       // "3 min" | "—"
  name: string;
  desc: string;
  pct: number;
  dim?: boolean;
}

export interface DataSource {
  label: string;
  icon: "map" | "sheet" | "globe";
  action: "arrow" | "plus";
}

export interface MapEntity {
  id: string;
  label: string;
  lat: number;
  lng: number;
  kind: MarkerKind;
  glyph: "diamond" | "chevron" | "square" | "triangle" | "vessel";
}

export type Autonomy = "IN-LOOP" | "ON-LOOP" | "SUPERVISED";

export type AlertSeverity = "critical" | "caution" | "info";

export interface Alert {
  id: string;
  severity: AlertSeverity;
  title: string;
  time: string;
  description: string;
  source: string;
  unread?: boolean;
}

export type AuditEntryKind = "authorised" | "system" | "classification";

export interface AuditEntry {
  id: string;
  kind: AuditEntryKind;
  title: string;
  timestamp: string;
}

export interface SoulExchange {
  id: string;
  userText: string;
}
