"use client";

import { useState } from "react";
import dynamic from "next/dynamic";
import type { Map as LeafletMap } from "leaflet";
import { Crosshair, Layers, Maximize2, Plus, Minus, Pencil, RotateCcw, PanelRight } from "lucide-react";
import { TimelineBar } from "./TimelineBar";

const MapCanvas = dynamic(() => import("./MapCanvas"), {
  ssr: false,
  loading: () => <div className="map-stub" />,
});

export function BattleMap({
  entitiesOpen,
  onToggleEntities,
}: {
  entitiesOpen: boolean;
  onToggleEntities: () => void;
}) {
  const [dim, setDim] = useState<"2D" | "3D">("3D");
  const [map, setMap] = useState<LeafletMap | null>(null);

  return (
    <div className="map">
      <div className="leaflet-wrap">
        <MapCanvas onReady={setMap} />
      </div>

      <div className="map-ov battle-tag">
        <Crosshair size={14} />
        <span className="t up">Battle overview</span>
      </div>

      <div className="map-ov map-tr">
        <div className="dtoggle">
          <button type="button" className={dim === "2D" ? "on" : ""} onClick={() => setDim("2D")}>2D</button>
          <button type="button" className={dim === "3D" ? "on" : ""} onClick={() => setDim("3D")}>3D</button>
        </div>
        <button
          type="button"
          className={`map-icobtn ent-toggle${entitiesOpen ? " on" : ""}`}
          aria-label="Toggle entities panel"
          aria-expanded={entitiesOpen}
          onClick={onToggleEntities}
        >
          <PanelRight size={16} />
        </button>
        <button type="button" className="map-icobtn" aria-label="Layers"><Layers size={16} /></button>
        <button type="button" className="map-icobtn" aria-label="Fullscreen"><Maximize2 size={16} /></button>
        <button type="button" className="map-icobtn" aria-label="Reset view"><RotateCcw size={16} /></button>
        <button type="button" className="map-lock-fab" aria-label="Target lock">
          <Crosshair size={18} />
        </button>
        <div className="zoom">
          <button type="button" onClick={() => map?.zoomIn()} aria-label="Zoom in"><Plus size={15} /></button>
          <button type="button" onClick={() => map?.zoomOut()} aria-label="Zoom out"><Minus size={15} /></button>
        </div>
      </div>

      <div className="map-ov map-cursor">
        <span className="g"><Crosshair size={13} /> Cursor: offscreen</span>
        <span className="g mono"><Pencil size={12} /> MGRS 113</span>
      </div>

      <div className="map-ov map-scale">
        20 mi
        <div className="ruler" />
      </div>

      <div className="map-bottom">
        <TimelineBar />
      </div>
    </div>
  );
}
