import type { Entity, Coa, DataSource, MapEntity, Alert, AuditEntry } from "./types";
import type { HumanAuthorityGate } from "./gate-types";

/* ---- right-panel entity roster ------------------------------------------- */
export const ENTITIES: Entity[] = [
  { id: "mx1", name: "MEGHA X STRIKER 1-1", badge: "HYENA", sub: "HYENA · Autonomous Strike UAV", confidence: 100, tone: "hy", status: "var(--green)" },
  { id: "mx2", name: "MEGHA X STRIKER 1-2", badge: "HYENA", sub: "HYENA · Autonomous Strike UAV", confidence: 100, tone: "hy", status: "var(--green)" },
  { id: "sa", name: "SENTINEL ALPHA", badge: "SENTINEL", sub: "SENTINEL · sentry C2 Radar Node", confidence: 100, tone: "sent", status: "var(--friendly)" },
  { id: "int3", name: "INTERCEPTOR-3", badge: "SENTINEL", sub: "SENTINEL · Node 01 C-UAS Interceptor", confidence: 100, tone: "sent", status: "var(--amber)" },
  { id: "grd7", name: "GUARDIAN-7", badge: "SENTINEL", sub: "SENTINEL · Node 01 C-UAS Interceptor", confidence: 100, tone: "sent", status: "var(--green)" },
  { id: "t552", name: "TRACK 552", badge: "", sub: "Group-3 UAS · Probable", confidence: 82, tone: "host", status: "var(--cyan)" },
  { id: "t553", name: "TRACK 553", badge: "", sub: "Group-3 UAS · Probable", confidence: 77, tone: "host", status: "var(--cyan)" },
  { id: "t559", name: "TRACK 559", badge: "", sub: "Rotary Wing · Unknown", confidence: 53, tone: "host", status: "var(--caution)" },
  { id: "shk", name: "SEAHAWK", badge: "", sub: "Vessel · Data Link", confidence: 93, tone: "frnd", status: "var(--green)" },
  { id: "c4421", name: "CIVIL 4421", badge: "", sub: "Commercial Air · ADS-B", confidence: 99, tone: "neut", status: "var(--cyan)" },
];

export const ENT_FILTERS = [
  { key: "ALL", n: 10 },
  { key: "FRND", n: 5 },
  { key: "HOST", n: 2 },
  { key: "UNK", n: 1 },
  { key: "NEUT", n: 2 },
] as const;

export const COAS: Coa[] = [
  { id: "COA-A", rec: true, time: "3 min", name: "Engage with INTERCEPTOR-3", desc: "Kinetic intercept · positive seeker lock · 3 min to effect", pct: 88 },
  { id: "COA-B", time: "6 min", name: "Cue REAPER 1-1 to shadow", desc: "Maintain custody, defer engagement, collect EO/IR ID", pct: 72 },
  { id: "COA-C", time: "—", name: "Hold & monitor", desc: "No effector committed · re-evaluate at sector boundary", pct: 40, dim: true },
];

/* ---- SOUL chat demo reply ---------------------------------------------- */
export const SOUL_DEFAULT_REPLY =
  "Tasking MEGHA X STRIKER 1-1 + STRIKER 1-2 to grid search of the northern ridge. Estimated coverage 4 minutes.";

/* ---- ALERTS tab rows --------------------------------------------------- */
export const ALERTS: Alert[] = [
  {
    id: "a1",
    severity: "critical",
    title: "Hostile UAS pair inbound",
    time: "00:42",
    description: "TRACK 552 / 553 crossing into protected airspace · authorisation required",
    source: "SENTINEL ALPHA",
    unread: true,
  },
  {
    id: "a2",
    severity: "caution",
    title: "Low fuel — REAPER 1-2",
    time: "02:31",
    description: "Bingo fuel in 18 min at current tasking",
    source: "HYENA",
  },
  {
    id: "a3",
    severity: "info",
    title: "New external sensor online",
    time: "06:14",
    description: "GUARDIAN-7 AEW&C integrated via SDK · feeding air picture",
    source: "ARC C2",
  },
  {
    id: "a4",
    severity: "caution",
    title: "Unknown rotary loitering",
    time: "03:02",
    description: "TRACK 559 holding near sector boundary · classification pending",
    source: "Perception Agent",
  },
];

/* ---- Human Authority Gate (Decide → REVIEW & AUTHORISE) ---------------- */
export const DEMO_AUTHORITY_GATE: HumanAuthorityGate = {
  id: "gate-track-552",
  title: "HUMAN AUTHORITY GATE",
  taskType: "DEFEAT TASK · LETHAL/DEFEAT AUTHORIZATION REQUIRED",
  target: { label: "TRACK 552", sub: "Group-3 UAS · Probable" },
  classification: { label: "HOSTILE", confidence: 88 },
  effector: { label: "SE-204", sub: "INTERCEPTOR-3 · kinetic" },
  predictedIntercept: { label: "3 min", sub: "Positive seeker lock" },
  targetRange: { label: "4.2 km", sub: "WEZ envelope · inbound NW" },
  rationale:
    "Two hostile Group-3 UAS inbound on protected airspace at 96 kts. INTERCEPTOR-3 is the lowest-cost, fastest effector with positive seeker lock. Engagement deconflicted against REAPER 1-1.",
  policyId: "ROE-AIR-DEFENSE-07",
  authoriser: "CDR. VOSS",
  auditSink: "ARC C2 · Tamper-evident audit log",
  roeRules: [
    { id: "roe-1", label: "Positive hostile classification confirmed for TRACK 552" },
    { id: "roe-2", label: "Effector WEZ clear of civil traffic / fratricide risk" },
    { id: "roe-3", label: "Authorising officer holds DEFEAT authority under ROE-AIR-DEFENSE-07" },
    { id: "roe-4", label: "Collateral / ROE proportionality reviewed for this engagement" },
  ],
};

/* ---- AUDIT tab entries ------------------------------------------------- */
export const AUDIT_ENTRIES: AuditEntry[] = [
  {
    id: "e1",
    kind: "authorised",
    title: "INTERCEPT SE-204 → TRACK 552 (Group-3 UAS) AUTHORISED · CDR. VOSS · ROE-AIR-DEFENSE-07",
    timestamp: "09:01:29Z",
  },
  {
    id: "e2",
    kind: "system",
    title: "GUARDIAN-7 external AEW&C onboarded via integration SDK",
    timestamp: "08:56:11Z",
  },
  {
    id: "e3",
    kind: "classification",
    title: "TRACK 552 reclassified HOSTILE · confidence 0.92 (Perception)",
    timestamp: "08:02:11Z",
  },
  {
    id: "e4",
    kind: "system",
    title: "REAPER 1-1 tasked INVESTIGATE TRACK 559 · authoriser CDR. VOSS",
    timestamp: "08:01:22Z",
  },
];

export const DATA_SOURCES: DataSource[] = [
  { label: "Maps", icon: "map", action: "arrow" },
  { label: "Sheets", icon: "sheet", action: "arrow" },
  { label: "Satellite Imagery", icon: "globe", action: "arrow" },
  { label: "MEGHA ISR | HYENA", icon: "globe", action: "arrow" },
  { label: "Historical Tracks", icon: "globe", action: "arrow" },
];

export const LIVE_LAYERS: DataSource[] = [
  { label: "Live Global Blue Force Tracks (BFT)", icon: "globe", action: "arrow" },
  { label: "Live Global ISR Assets", icon: "globe", action: "arrow" },
  { label: "Live Maritime Data", icon: "globe", action: "plus" },
];

/* ---- map markers (around Jaffna, Sri Lanka) ------------------------------ */
export const MAP_CENTER: [number, number] = [9.72, 80.02];
export const MAP_ZOOM = 11;

export const MAP_ENTITIES: MapEntity[] = [
  { id: "mx1", label: "MEGHA X STRIKER 1-1", lat: 9.86, lng: 80.05, kind: "hy", glyph: "chevron" },
  { id: "mx2", label: "MEGHA X STRIKER 1-2", lat: 9.87, lng: 80.12, kind: "hy", glyph: "chevron" },
  { id: "t552t", label: "TRACK 552", lat: 9.80, lng: 79.86, kind: "host", glyph: "diamond" },
  { id: "t553", label: "TRACK 553", lat: 9.78, lng: 79.95, kind: "host", glyph: "diamond" },
  { id: "seasa", label: "SEASENTINEL ALPHA", lat: 9.79, lng: 79.92, kind: "sent", glyph: "square" },
  { id: "civ", label: "CIVIL 4421", lat: 9.76, lng: 79.83, kind: "sent", glyph: "triangle" },
  { id: "sa1", label: "SENTINEL ALPHA", lat: 9.74, lng: 80.06, kind: "sent", glyph: "square" },
  { id: "scuas", label: "SENTINEL C UAS", lat: 9.75, lng: 80.12, kind: "sent", glyph: "chevron" },
  { id: "sa2", label: "SENTINEL ALPHA", lat: 9.70, lng: 79.98, kind: "sent", glyph: "square" },
  { id: "sa3", label: "SENTINEL ALPHA", lat: 9.64, lng: 79.93, kind: "sent", glyph: "square" },
  { id: "t552b", label: "TRACK 552", lat: 9.62, lng: 79.85, kind: "host", glyph: "diamond" },
  { id: "reaper", label: "REAPER 1-2", lat: 9.62, lng: 80.10, kind: "sent", glyph: "chevron" },
  { id: "sa4", label: "SENTINEL ALPHA", lat: 9.57, lng: 80.18, kind: "sent", glyph: "square" },
];

export const MAP_PLACES = [
  { label: "GAJABA SL NAVY HQ", lat: 9.685, lng: 80.02, big: false },
  { label: "JAFFNA", lat: 9.70, lng: 80.10, big: true },
];

// dashed contact-path polylines [ [lat,lng], ... ]
export const MAP_PATHS: { color: string; pts: [number, number][] }[] = [
  { color: "#22C1C3", pts: [[9.80, 79.86], [9.78, 79.95], [9.74, 80.06]] },
  { color: "#F5C518", pts: [[9.87, 80.12], [9.70, 79.98], [9.62, 79.85]] },
];
