"use client";

import { useState } from "react";
import {
  Play, Pause, ChevronDown, Plus, ChevronLeft, Search,
  Circle, MoreHorizontal, Diamond, SquareDashed, PlusSquare, Video,
} from "lucide-react";

const MONTHS = ["June 6th", "June 7th", "June 8th", "June 9th"];

export function TimelineBar() {
  const [playing, setPlaying] = useState(false);
  const [q, setQ] = useState("");
  const [checks, setChecks] = useState({ layers: true, tools: false, sources: false });

  const toggle = (k: keyof typeof checks) => setChecks((c) => ({ ...c, [k]: !c[k] }));

  return (
    <div className="timeline">
      <div className="tl-top">
        <span className="tl-title">Timeline</span>
        <div className="tl-ctrls">
          <button className="cb" onClick={() => setPlaying(true)}><Play size={14} /></button>
          <button className="cb" onClick={() => setPlaying(false)}><Pause size={14} /></button>
        </div>
        <button className={`tl-play${playing ? " on" : ""}`} onClick={() => setPlaying((p) => !p)}>
          <Play size={13} /> {playing ? "Playing" : "Play"}
        </button>

        <div className="tl-annot">
          <span>Adding to</span>
          <span className="pick"><Diamond size={12} className="di" fill="var(--cyan)" /> Annotations <ChevronDown size={13} /></span>
          <span className="new"><Plus size={13} style={{ display: "inline" }} /> New</span>
          <ChevronLeft size={14} />
        </div>

        <div className="tl-search">
          <Search size={13} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="" />
        </div>

        <div className="tl-checks">
          <button className={`tl-check${checks.layers ? " on" : ""}`} onClick={() => toggle("layers")}>
            <span className="box" /> Map layers
          </button>
          <button className={`tl-check${checks.tools ? " on" : ""}`} onClick={() => toggle("tools")}>
            <span className="box" /> Tools
          </button>
          <button className={`tl-check${checks.sources ? " on" : ""}`} onClick={() => toggle("sources")}>
            <span className="box" /> Data sources
          </button>
        </div>
      </div>

      <div className="tl-symrow">
        <span className="sym">SYMBOL <ChevronDown size={12} /></span>
        <button className="si"><Circle size={14} /></button>
        <button className="si"><MoreHorizontal size={14} /></button>
        <button className="si"><Diamond size={13} /></button>
        <button className="si"><SquareDashed size={14} /></button>
        <button className="si"><PlusSquare size={14} /></button>
        <button className="si"><Video size={14} /></button>
      </div>

      <div className="tl-body">
        <div className="tl-track">
          <div className="tl-months">
            {MONTHS.map((m) => <div className="tl-month" key={m}>{m}</div>)}
          </div>
          <div className="tl-live"><span className="dot" style={{ background: "var(--green)" }} /> LIVE</div>
          <div className="tl-rows">
            <div className="tl-row">
              <div className="tl-blk pink" /><div className="tl-blk pink" /><div className="tl-blk pink" />
              <div style={{ width: 380 }} />
              <div className="tl-blk pink" />
            </div>
            <div className="tl-row">
              <div className="tl-blk green" /><div className="tl-blk green" /><div className="tl-blk green" />
            </div>
          </div>
          <div className="tl-play-head" style={{ left: "62%" }}>
            <span className="tag mono">16:45:01</span>
          </div>
        </div>

        <div className="tl-legend">
          <div className="tl-leg"><span className="sw sw-imagery" /> Satellite Imagery <span className="c">4</span></div>
          <div className="tl-leg"><span className="sw sw-signals" /> Signals Intel <span className="c">3</span></div>
        </div>
      </div>
    </div>
  );
}
