"use client";

import { useState } from "react";
import { Search, Bell, User, Globe } from "lucide-react";

/**
 * Renders an uppercase word with a single letter accented in yellow.
 * `hl` is the 0-based index of the letter to highlight.
 */
function AccentWord({ word, hl }: { word: string; hl: number }) {
  const chars = word.toUpperCase().split("");
  return (
    <>
      {chars.map((ch, i) =>
        i === hl ? (
          <span className="tb-hl" key={i}>{ch}</span>
        ) : (
          ch
        ),
      )}
    </>
  );
}

type NavTab = "C2" | "HYENA" | "SENTINEL";

const NAV_TABS: { id: NavTab; label: React.ReactNode }[] = [
  { id: "C2", label: "C2 BATTLE MANAGEMENT" },
  { id: "HYENA", label: <AccentWord word="HYENA" hl={2} /> },      // HY[E]NA
  { id: "SENTINEL", label: <AccentWord word="SENTINEL" hl={3} /> }, // SEN[T]INEL
];

export function TopBar() {
  const [activeTab, setActiveTab] = useState<NavTab>("C2");

  return (
    <header className="topbar">
      <div className="tb-left">
        <span className="tb-logo" aria-hidden>
          <Globe size={16} />
        </span>
        <span className="tb-brand">
          ARC <AccentWord word="OS" hl={0} />
        </span>

        <div className="tb-tabs" role="tablist" aria-label="ARC OS sections">
          {NAV_TABS.map((tab) => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={activeTab === tab.id}
              className={`tb-tab${activeTab === tab.id ? " on" : ""}`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <span className="tb-div" aria-hidden />
        <span className="tb-stat">
          <span className="dot tb-dot-on" />
          LINK <b className="mono">10MS</b>
        </span>
        <span className="tb-stat tb-auto">
          AUTONOMY: <b>ON-LOOP</b>
        </span>
      </div>

      <div className="tb-right">
        <span className="conf up">CONFIDENTIAL</span>
        <button type="button" className="tb-ico" aria-label="Search">
          <Search size={16} />
        </button>
        <button type="button" className="tb-ico" aria-label="Notifications">
          <Bell size={16} />
          <span className="badge" />
        </button>
        <div className="tb-user">
          <span className="dot tb-online" />
          <div className="ava"><User size={15} /></div>
          <div className="nm">
            <b>K. Premachandra</b>
            <span>Commander · ROE-Alpha</span>
          </div>
        </div>
      </div>
    </header>
  );
}
