"use client";

import { useEffect } from "react";
import { MapContainer, TileLayer, Marker, Polyline, useMap } from "react-leaflet";
import L from "leaflet";
import { MAP_CENTER, MAP_ZOOM, MAP_ENTITIES, MAP_PLACES, MAP_PATHS } from "./data";
import type { MapEntity } from "./types";

const KIND_COLOR: Record<MapEntity["kind"], string> = {
  host: "#F04438",
  hy: "#2FBF71",
  sent: "#2FBF71",
  frnd: "#2FBF71",
};

function glyphSvg(g: MapEntity["glyph"], c: string): string {
  switch (g) {
    case "diamond":
      return `<svg width="18" height="18" viewBox="0 0 18 18"><rect x="4.5" y="4.5" width="9" height="9" transform="rotate(45 9 9)" fill="none" stroke="${c}" stroke-width="1.8"/><circle cx="9" cy="9" r="1.4" fill="${c}"/></svg>`;
    case "chevron":
      return `<svg width="18" height="18" viewBox="0 0 18 18"><path d="M9 4 L14 14 L9 11.5 L4 14 Z" fill="none" stroke="${c}" stroke-width="1.6"/></svg>`;
    case "triangle":
      return `<svg width="18" height="18" viewBox="0 0 18 18"><path d="M9 4 L14 13 L4 13 Z" fill="none" stroke="${c}" stroke-width="1.6"/></svg>`;
    case "square":
    default:
      return `<svg width="16" height="16" viewBox="0 0 16 16"><rect x="3" y="3" width="10" height="10" rx="1.5" fill="none" stroke="${c}" stroke-width="1.8"/></svg>`;
  }
}

function entityIcon(e: MapEntity): L.DivIcon {
  const c = KIND_COLOR[e.kind];
  return L.divIcon({
    className: "",
    html: `<div class="mk ${e.kind}"><div class="glyph">${glyphSvg(e.glyph, c)}</div><div class="lab">${e.label}</div></div>`,
    iconSize: [10, 10],
    iconAnchor: [5, 5],
  });
}

function placeIcon(label: string, big: boolean): L.DivIcon {
  return L.divIcon({
    className: "",
    html: big ? `<div class="mk-big">${label}</div>` : `<div class="mk-place">${label}</div>`,
    iconSize: [0, 0],
  });
}

function MapReady({ onReady }: { onReady?: (m: L.Map) => void }) {
  const map = useMap();
  useEffect(() => { onReady?.(map); }, [map, onReady]);
  return null;
}

function MapResizer() {
  const map = useMap();

  useEffect(() => {
    const mapCell = map.getContainer().closest(".map");
    if (!mapCell) return;

    let raf = 0;
    const observer = new ResizeObserver(() => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => map.invalidateSize());
    });
    observer.observe(mapCell);
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
    };
  }, [map]);

  return null;
}

export default function MapCanvas({ onReady }: { onReady?: (m: L.Map) => void }) {
  return (
    <MapContainer
      center={MAP_CENTER}
      zoom={MAP_ZOOM}
      zoomControl={false}
      attributionControl={false}
      className="leaflet-container"
    >
      <MapReady onReady={onReady} />
      <MapResizer />
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" maxZoom={19} />

      {MAP_PATHS.map((p, i) => (
        <Polyline key={i} positions={p.pts} pathOptions={{ color: p.color, weight: 1.5, dashArray: "6 4", opacity: 0.85 }} />
      ))}

      {MAP_ENTITIES.map((e) => (
        <Marker key={e.id} position={[e.lat, e.lng]} icon={entityIcon(e)} />
      ))}

      {MAP_PLACES.map((p) => (
        <Marker key={p.label} position={[p.lat, p.lng]} icon={placeIcon(p.label, p.big)} interactive={false} />
      ))}
    </MapContainer>
  );
}
