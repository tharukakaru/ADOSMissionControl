"use client";

import { useCallback, useRef, useState, type KeyboardEvent } from "react";
import {
  Sparkles, Search, Server, ChevronRight, Mic, Send, Ban,
  ArrowLeftRight, Tag, Activity, AlertTriangle,
} from "lucide-react";
import { SOUL_DEFAULT_REPLY } from "./data";
import type { SoulExchange } from "./types";

function Diamond({ color }: { color: string }) {
  return (
    <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden>
      <rect x="2" y="2" width="8" height="8" transform="rotate(45 6 6)" fill={color} />
    </svg>
  );
}

function TurnLabel({ sub }: { sub?: boolean }) {
  if (sub) {
    return (
      <div className="turn-lbl sub">
        <Diamond color="var(--cyan-b)" />
        <span className="who">HYENA ISR-MEGHA X AGENT</span>
        <ChevronRight size={13} className="chev" />
      </div>
    );
  }
  return (
    <div className="turn-lbl">
      <Diamond color="var(--yellow)" />
      <span className="who">SOUL</span>
      <ChevronRight size={13} className="chev" />
      <span className="src-badge"><Server size={11} /> GROUND DGX</span>
    </div>
  );
}

export function SoulChat({ onAuthorise }: { onAuthorise: () => void }) {
  const [query, setQuery] = useState("");
  const [intent, setIntent] = useState("");
  const [exchanges, setExchanges] = useState<SoulExchange[]>([]);
  const chatRef = useRef<HTMLDivElement>(null);

  const scrollChatToBottom = useCallback(() => {
    requestAnimationFrame(() => {
      chatRef.current?.scrollTo({ top: chatRef.current.scrollHeight, behavior: "smooth" });
    });
  }, []);

  const sendIntent = useCallback(() => {
    const text = intent.trim();
    if (!text) return;
    setExchanges((prev) => [...prev, { id: crypto.randomUUID(), userText: text }]);
    setIntent("");
    scrollChatToBottom();
  }, [intent, scrollChatToBottom]);

  const onIntentKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendIntent();
    }
  };

  return (
    <aside className="soul">
      <div className="soul-head">
        <div className="soul-head-brand">
          <Sparkles size={11} className="spark" aria-hidden />
          <span className="t1">SOUL 001</span>
          <span className="t2">· NOW</span>
          <span className="t3">Chat with</span>
        </div>
        <div className="soul-search">
          <Search size={12} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Query entity, callsign, or coordinate…"
          />
        </div>
      </div>

      <div className="chat" ref={chatRef}>
        <div className="chat-op">OPERATOR | COMMANDER · ROE-ALPHA ›</div>

        <div className="msg-user">search the northern Jaffana and report any vehicles</div>

        <div className="turn">
          <TurnLabel />
          <div className="bubble">
            Tasking MEGHA X STRIKER 1-1 + STRIKER 1-2 to grid search of the northern ridge.
            Estimated coverage 4 minutes.
          </div>
          <div className="code mono">
            <div><span className="k">search_area</span> assets:<span className="v">STRIKER 1-1, STRIKER 1-2</span></div>
            <div><span className="k">region</span>:<span className="v">northern_Jaffna</span></div>
          </div>
        </div>

        <div className="turn">
          <TurnLabel />
          <TurnLabel sub />
          <div className="bubble">
            SENTINEL ALPHA Radar Mesh Holds Two Low Contacts Inbound Over Jaffna Lagoon, NW Bearing
            Toward Gajaba HQ. Correlated To TRACK 552 (Group-3 UAS · 82%) And TRACK 553 (Group-3 UAS · 77%).
            TRACK 552 — Lead Track — 2,400 Ft, Closing. CIVIL 4421 Deconflicted Via ADS-B. Recommend
            Interceptor Engagement On TRACK 552. Requires Your Authorization.
          </div>
        </div>

        <div className="turn">
          <TurnLabel />
          <div className="bubble">
            Decision staged. INTERCEPT → TRACK 552 with INTERCEPTOR-3, effector SE-204, positive seeker
            lock, 3 min to effect. 88% confidence. Three courses of action posted to DECIDE. Human gate required.
          </div>
          <div className="code danger mono">
            <div><span className="k">engage_target</span>&nbsp;&nbsp;&nbsp;target:<span className="v">TRACK 552</span></div>
            <div>asset:<span className="v">INTERCEPTOR-3</span>&nbsp;&nbsp;effector:<span className="v">SE-204</span></div>
          </div>
          <button className="btn-red sm" onClick={onAuthorise}>
            <Ban size={15} /> REVIEW &amp; AUTHORISE <ChevronRight size={15} />
          </button>
        </div>

        {exchanges.map((ex) => (
          <div key={ex.id}>
            <div className="msg-user">{ex.userText}</div>
            <div className="turn">
              <TurnLabel />
              <div className="bubble">{SOUL_DEFAULT_REPLY}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="soul-input">
        <Mic size={16} className="mic" />
        <input
          value={intent}
          onChange={(e) => setIntent(e.target.value)}
          onKeyDown={onIntentKeyDown}
          placeholder="type intent ›"
        />
        <button type="button" className="send" onClick={sendIntent} aria-label="Send intent">
          <Send size={14} />
        </button>
      </div>

      <div className="soul-actions">
        <button className="sa"><ArrowLeftRight size={14} /> HANDOFF</button>
        <button className="sa"><Tag size={14} /> CLASSIFY</button>
        <button className="sa"><Activity size={14} /> TRACK</button>
        <button className="sa danger"><AlertTriangle size={14} /> ENGAGE</button>
      </div>
    </aside>
  );
}
