"use client";

import { useState } from "react";
import {
  Sparkles, ChevronRight, ChevronDown, Plus, Map as MapIcon, Table2, Globe,
  LayoutGrid, User, Eye, ShieldCheck, Ban,
} from "lucide-react";
import { ALERTS, COAS, DATA_SOURCES, LIVE_LAYERS } from "./data";
import { AlertsTab } from "./AlertsTab";
import { AuditTab } from "./AuditTab";
import type { Autonomy, DataSource } from "./types";

const DS_ICON = { map: MapIcon, sheet: Table2, globe: Globe } as const;

function SourceRow({ s }: { s: DataSource }) {
  const Icon = DS_ICON[s.icon];
  return (
    <button type="button" className="drow">
      <span className="di"><Icon size={15} /></span>
      {s.label}
      <span className="arr">{s.action === "plus" ? <Plus size={14} /> : <ChevronRight size={14} />}</span>
    </button>
  );
}

const AUTON: { key: Autonomy; icon: typeof User }[] = [
  { key: "IN-LOOP", icon: User },
  { key: "ON-LOOP", icon: Eye },
  { key: "SUPERVISED", icon: ShieldCheck },
];

type DecideTab = "DECIDE" | "ALERTS" | "AUDIT";

export function DecidePanel({
  autonomy, setAutonomy, onRequestAuthorise, forceTab,
}: {
  autonomy: Autonomy;
  setAutonomy: (a: Autonomy) => void;
  onRequestAuthorise: () => void;
  forceTab?: DecideTab;
}) {
  const [tab, setTab] = useState<DecideTab>("DECIDE");
  const [coa, setCoa] = useState("COA-A");

  const activeTab = forceTab ?? tab;

  const themed = activeTab === "ALERTS" || activeTab === "AUDIT";
  const sectionClass = [
    "decide",
    themed ? "decide--themed" : "",
  ].filter(Boolean).join(" ");

  return (
    <section className={sectionClass}>
      <div className="dec-tabs">
        <button
          type="button"
          className={`dtab dtab-decide${activeTab === "DECIDE" ? " on" : ""}`}
          onClick={() => setTab("DECIDE")}
        >
          DECIDE <span className="cbadge">1</span>
        </button>
        <button
          type="button"
          className={`dtab dtab-alerts${activeTab === "ALERTS" ? " on" : ""}`}
          onClick={() => setTab("ALERTS")}
        >
          ALERTS <span className="cbadge cbadge-alerts">{ALERTS.length}</span>
        </button>
        <button
          type="button"
          className={`dtab dtab-audit${activeTab === "AUDIT" ? " on" : ""}`}
          onClick={() => setTab("AUDIT")}
        >
          AUDIT
        </button>
      </div>

      <div className="dec-body">
        {activeTab === "DECIDE" && (
          <div className="dec-scroll">
            <div className="dec-sub">
              <Sparkles size={14} className="spark" />
              <span className="t">SOUL AI · DECISION</span>
              <span className="agent">DECISION AGENT</span>
            </div>

            <div className="await">
              <div className="lbl">AWAITING AUTHORISATION</div>
              <div className="ttl">INTERCEPT → TRACK 552 (Group-3 UAS)</div>
              <div className="sub">Effector SE-204 · 88% confidence</div>
            </div>

            <div className="sec-lbl">RECOMMENDED COURSES OF ACTION</div>

            {COAS.map((c) => (
              <div
                key={c.id}
                className={`coa${coa === c.id ? " on" : ""}${c.dim ? " dim" : ""}`}
                onClick={() => setCoa(c.id)}
                onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") setCoa(c.id); }}
                role="button"
                tabIndex={0}
              >
                <div className="r1">
                  <span className="id">{c.id}</span>
                  {c.rec && <span className="rec">REC</span>}
                  <span className="time">{c.time}</span>
                </div>
                <div className="name">{c.name}</div>
                <div className="desc">{c.desc}</div>
                <div className="meter">
                  <div className={`bar${c.dim ? " dim" : ""}`}><i style={{ width: `${c.pct}%` }} /></div>
                  <span className="pct">{c.pct}%</span>
                </div>
              </div>
            ))}

            <div className="dec-note">
              Every recommendation is explainable and traced to the entities, rules, and reasoning that
              produced it. Use of force always requires a positive human gate.
            </div>

            <div className="dec-hr" />

            <div className="dsrc">
              <div className="dsrc-h">
                <ChevronRight size={13} className="cx" />
                <span className="t">Integrated data sources</span>
                <span className="n">9</span>
              </div>
              <div className="dsrc-sub"><span>Database</span><span># in view <ChevronDown size={11} style={{ display: "inline" }} /></span></div>
              {DATA_SOURCES.map((s) => <SourceRow key={s.label} s={s} />)}
              <button type="button" className="viewall">View all</button>
            </div>

            <div className="dsrc" style={{ paddingTop: 0 }}>
              <div className="dsrc-h">
                <ChevronRight size={13} className="cx" />
                <span className="t">Live data layers</span>
                <span className="n">21</span>
              </div>
              <div style={{ height: 6 }} />
              {LIVE_LAYERS.map((s) => <SourceRow key={s.label} s={s} />)}
              <button type="button" className="viewall">View all</button>
            </div>
          </div>
        )}

        {activeTab === "ALERTS" && <AlertsTab />}
        {activeTab === "AUDIT" && <AuditTab />}
      </div>

      {activeTab === "DECIDE" && (
        <div className="dec-footer">
          <button type="button" className="btn-red" onClick={onRequestAuthorise}>
            <Ban size={15} /> REVIEW &amp; AUTHORISE <ChevronRight size={15} />
          </button>
        </div>
      )}

      <div className="autonomy">
        <div className="autonomy-h"><LayoutGrid size={13} /> LEVEL OF AUTONOMY</div>
        <div className="auto-seg">
          {AUTON.map(({ key, icon: Icon }) => (
            <button
              key={key}
              type="button"
              className={`aseg${autonomy === key ? " on" : ""}`}
              onClick={() => setAutonomy(key)}
            >
              <Icon size={15} />
              {key}
            </button>
          ))}
        </div>
        <div className="auto-note">AI proposes, a human must approve every action.</div>
      </div>
    </section>
  );
}
