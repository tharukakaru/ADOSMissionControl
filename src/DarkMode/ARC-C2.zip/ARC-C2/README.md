# ARC OS · C2 — BATTLE MANAGEMENT (demo screen)

Flat set of React + TypeScript files that recreate the C2 battle-management
console. **Demo only**: dummy data, editable text fields, and clickable
controls — no backend, no real capability.

## Install the two runtime deps

```bash
npm i leaflet react-leaflet lucide-react
```

`react-leaflet` v5 targets React 19. Leaflet's stylesheet and this project's
stylesheet are imported at the top of `App.tsx`:

```ts
import "./arc.css";
import "leaflet/dist/leaflet.css";
```

## Files (all flat — no folders needed)

```
App.tsx           entry — composes the whole screen, holds shared "autonomy" state
arc.css           all styling (scoped under .arc) + CSS variables for the palette
types.ts          shared types
data.ts           dummy data: entities, COAs, data sources, map markers, paths

TopBar.tsx        ARC OS logo, C2 block, HYENA/SENTINEL tabs, LINK/AUTONOMY, user
IconRail.tsx      left icon strip
SoulChat.tsx      left "SOUL 001" chat column (editable query + intent inputs)
DecidePanel.tsx   center DECIDE/ALERTS/AUDIT panel, COA cards, autonomy selector
BattleMap.tsx     map region: overlays + dynamically-loaded Leaflet canvas + timeline
MapCanvas.tsx     the actual Leaflet map (OpenStreetMap tiles, markers, paths)
EntitiesPanel.tsx right ENTITIES roster + Range-ring / Alerts / Terrain tools
TimelineBar.tsx   bottom timeline (play/pause, checkboxes, scrubber, legend)
```

## Map notes

- Uses **OpenStreetMap** raster tiles via `react-leaflet`
  (`https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png`), centred on Jaffna.
- Leaflet reads `window` at import, so `MapCanvas` is loaded through
  `next/dynamic(..., { ssr: false })` inside `BattleMap`. If you're **not** on
  Next.js, replace that dynamic import with your framework's client-only
  loader (or render `MapCanvas` only after mount). Everything else is
  framework-agnostic React.
- Entity markers and place labels are Leaflet `divIcon`s styled by the
  `.mk` / `.mk-place` / `.mk-big` classes in `arc.css`.

## What's interactive (demo)

Editable: the SOUL query field, the "type intent" field, and the timeline
search. Clickable with live state: DECIDE/ALERTS/AUDIT tabs, COA selection,
LEVEL OF AUTONOMY (syncs to the top bar), entity filters, 2D/3D toggle, map
zoom +/-, timeline Play/Pause and the Map layers / Tools / Data sources
checkboxes. The red **REVIEW & AUTHORISE** buttons call an `onAuthorise`
no-op hook in `App.tsx` — wire it to real logic there.

## Usage

Render `<App />` (default export of `App.tsx`) as a full-screen route. It
fills the viewport (`.arc` is `100vw × 100vh`).

Verified: strict `tsc` passes; layout checked against the reference via
server-side render + screenshot (map tiles load in-browser only).
